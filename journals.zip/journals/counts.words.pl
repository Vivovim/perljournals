#!/usr/bin/perl -w
## Wed Dec 23 20:09:34 MST 2015
## Christopher ctopher@mac.com

use strict;

my @files       = <*.journals.txt>;

my @set         = ();


my $count_S     = "0";
my $count_F     = "0";
my $death       = "0";
my $care		= "0";

foreach my $file (@files) {

	open (FI, $file) || die "Sorry Dave, Error # 01 $!";

	while (<FI>) {

        chomp;
        push @set, $_;


	}

}

foreach my $line (@set) {

        my @words = split(/\ /, $line);
		my @cares = split(/\./, $line);



		foreach my $cares2	(@cares) {
			if ($cares2 =~ /No one cares/i) {
					$care++;
			}
		}




        foreach my $word (@words) {
                if ($word =~ /shit|Shit/) {
                        $count_S++;

                }


                if ($word =~ /fuck|Fuck/) {
                        $count_F++;
                }

                if ($word =~ /die|Die|dead|Dead/) {
                        $death++;
                }

				


        }
        

        @words  = ();
		@cares	= ();

}



print "S-word: $count_S\n";
print "F-word: $count_F\n";
print "D-word: $death\n";
print "No one Cares: $care\n";


exit(0);



